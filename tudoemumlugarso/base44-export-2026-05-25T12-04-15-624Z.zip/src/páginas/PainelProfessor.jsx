const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from 'react';

import { CheckCircle2, XCircle, Eye, MessageSquare, Star, StarOff } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function PainelProfessor() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('pendente');
  const [selected, setSelected] = useState(null);
  const [feedback, setFeedback] = useState('');
  const [reviewerName, setReviewerName] = useState('');
  const [approving, setApproving] = useState(null);

  useEffect(() => {
    db.auth.me().then(u => {
      setReviewerName(u.full_name || u.email);
    }).catch(() => {});
    loadPosts();
  }, [filter]);

  const loadPosts = () => {
    setLoading(true);
    db.entities.Post.filter({ status: filter }, '-created_date', 50)
      .then(data => { setPosts(data); setLoading(false); })
      .catch(() => setLoading(false));
  };

  const handleAction = async (post, action) => {
    setApproving(post.id);
    const update = {
      status: action,
      reviewer_name: reviewerName,
      reviewer_feedback: feedback,
    };
    if (action === 'publicado' && !post.is_featured) {
      // Check if no featured posts
      const featured = await db.entities.Post.filter({ is_featured: true, status: 'publicado' });
      if (featured.length === 0) update.is_featured = true;
    }
    await db.entities.Post.update(post.id, update);
    
    // Approval pulse animation
    if (action === 'publicado') {
      const el = document.getElementById(`post-${post.id}`);
      if (el) el.classList.add('approve-pulse');
      setTimeout(() => el?.classList.remove('approve-pulse'), 700);
    }
    
    setPosts(prev => prev.filter(p => p.id !== post.id));
    setSelected(null);
    setFeedback('');
    setApproving(null);
  };

  const handleFeature = async (post) => {
    // Unfeature others
    const featured = await db.entities.Post.filter({ is_featured: true });
    await Promise.all(featured.map(p => db.entities.Post.update(p.id, { is_featured: false })));
    await db.entities.Post.update(post.id, { is_featured: true });
    setPosts(prev => prev.map(p => ({ ...p, is_featured: p.id === post.id })));
  };

  const filters = [
    { key: 'pendente', label: 'Aguardando' },
    { key: 'publicado', label: 'Publicados' },
    { key: 'rejeitado', label: 'Rejeitados' },
    { key: 'rascunho', label: 'Rascunhos' },
  ];

  return (
    <div className="min-h-screen bg-paper-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-12">
        <div className="red-thread mb-10">
          <div className="text-xs text-gray-400 uppercase tracking-widest mb-1">Moderação</div>
          <h1 className="text-3xl font-black text-ink-black uppercase tracking-tight">Painel do Professor</h1>
        </div>

        {/* Filter tabs */}
        <div className="flex border-b border-metric-grey mb-8 overflow-x-auto">
          {filters.map(f => (
            <button
              key={f.key}
              onClick={() => { setFilter(f.key); setSelected(null); }}
              className={`flex-shrink-0 px-6 py-3 text-sm font-bold uppercase tracking-widest border-b-2 transition-colors whitespace-nowrap ${
                filter === f.key
                  ? 'border-senac-red text-senac-red'
                  : 'border-transparent text-gray-400 hover:text-ink-black'
              }`}
            >
              {f.label}
              {f.key === 'pendente' && posts.length > 0 && filter === 'pendente' && (
                <span className="ml-2 bg-senac-red text-white text-xs px-1.5 py-0.5 font-black">
                  {posts.length}
                </span>
              )}
            </button>
          ))}
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* List */}
          <div className="flex-1 space-y-3">
            {loading ? (
              [...Array(4)].map((_, i) => (
                <div key={i} className="h-20 bg-gray-100 animate-pulse" />
              ))
            ) : posts.length === 0 ? (
              <div className="text-center py-16 text-gray-400">
                <div className="text-5xl font-black text-metric-grey mb-3">—</div>
                <p>Nenhuma publicação nesta categoria.</p>
              </div>
            ) : (
              posts.map(post => (
                <div
                  key={post.id}
                  id={`post-${post.id}`}
                  onClick={() => { setSelected(post); setFeedback(''); }}
                  className={`flex gap-4 p-4 border cursor-pointer transition-all ${
                    selected?.id === post.id
                      ? 'border-senac-red bg-white'
                      : 'border-metric-grey bg-white hover:border-ink-black'
                  }`}
                >
                  <div className="w-14 h-14 flex-shrink-0 bg-gray-100 overflow-hidden">
                    {post.cover_image_url ? (
                      <img src={post.cover_image_url} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-lg font-black text-gray-300">
                        {post.class_name?.[0]}
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-black text-senac-red uppercase">{post.class_name}</span>
                      {post.is_featured && <Star className="w-3 h-3 text-amber-500 fill-amber-500" />}
                    </div>
                    <h3 className="font-black text-ink-black text-sm truncate">{post.title}</h3>
                    <p className="text-xs text-gray-400 mt-0.5">
                      {post.author_name} · {post.created_date && format(new Date(post.created_date), "d MMM", { locale: ptBR })}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Review panel */}
          {selected && (
            <div className="lg:w-96 flex-shrink-0">
              <div className="bg-white border border-metric-grey p-6 sticky top-32">
                <div className="flex items-start gap-3 mb-4">
                  <div className="w-1 h-12 bg-senac-red flex-shrink-0 mt-1" />
                  <div>
                    <span className="text-xs font-bold text-senac-red uppercase tracking-widest">{selected.class_name}</span>
                    <h2 className="font-black text-ink-black text-lg leading-tight">{selected.title}</h2>
                    {selected.author_name && (
                      <p className="text-xs text-gray-400 mt-1">por {selected.author_name}</p>
                    )}
                  </div>
                </div>

                {selected.cover_image_url && (
                  <img src={selected.cover_image_url} alt="" className="w-full h-40 object-cover mb-4" />
                )}

                {selected.summary && (
                  <p className="text-sm text-gray-600 leading-relaxed mb-4 border-l-2 border-metric-grey pl-3">
                    {selected.summary}
                  </p>
                )}

                {/* Feedback */}
                <div className="mb-4">
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">
                    <MessageSquare className="w-3 h-3 inline mr-1" />
                    Feedback (opcional)
                  </label>
                  <textarea
                    value={feedback}
                    onChange={e => setFeedback(e.target.value)}
                    placeholder="Deixe um comentário construtivo para o aluno..."
                    rows={3}
                    className="w-full text-sm border border-metric-grey focus:border-senac-red outline-none p-3 resize-none placeholder:text-gray-300"
                  />
                </div>

                {filter === 'publicado' && (
                  <button
                    onClick={() => handleFeature(selected)}
                    className={`w-full flex items-center justify-center gap-2 py-2 text-xs font-bold uppercase tracking-widest mb-3 border transition-colors ${
                      selected.is_featured
                        ? 'bg-amber-50 border-amber-300 text-amber-700'
                        : 'border-metric-grey text-gray-500 hover:border-amber-400 hover:text-amber-600'
                    }`}
                  >
                    {selected.is_featured ? (
                      <><StarOff className="w-3 h-3" /> Remover do Destaque</>
                    ) : (
                      <><Star className="w-3 h-3" /> Definir como Destaque</>
                    )}
                  </button>
                )}

                {filter === 'pendente' && (
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => handleAction(selected, 'rejeitado')}
                      disabled={approving === selected.id}
                      className="flex items-center justify-center gap-2 py-3 text-sm font-bold uppercase tracking-wide border-2 border-red-200 text-red-600 hover:bg-red-600 hover:text-white hover:border-red-600 transition-colors disabled:opacity-40"
                    >
                      <XCircle className="w-4 h-4" />
                      Rejeitar
                    </button>
                    <button
                      onClick={() => handleAction(selected, 'publicado')}
                      disabled={approving === selected.id}
                      className="flex items-center justify-center gap-2 py-3 text-sm font-bold uppercase tracking-wide bg-senac-red text-white hover:bg-red-700 transition-colors disabled:opacity-40"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      {approving === selected.id ? 'Aprovando...' : 'Aprovar'}
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}