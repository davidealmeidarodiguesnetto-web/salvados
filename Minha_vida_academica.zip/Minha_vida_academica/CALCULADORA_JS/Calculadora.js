let num1 = parseFloat(prompt("Digite o primeiro número:"));
let num2 = parseFloat(prompt("Digite o segundo número:"));

let operacao = prompt("Escolha a operação (+, -, *, /):");

let resultado;
let operacaoValida = true;

switch (operacao) {
    case "+":
        resultado = num1 + num2;
        break;
    case "-":
        resultado = num1 - num2;
        break;
    case "*":
        resultado = num1 * num2;
        break;
    case "/":
        if (num2 === 0) {
            alert("Erro: Não é possível dividir por zero!");
            operacaoValida = false;
        } else {
            resultado = num1 / num2;
        }
        break;
    default:
        alert("Operação inválida! Escolha entre +, -, * ou /.");
        operacaoValida = false;
}

if (operacaoValida) {
    alert("O resultado de " + num1 + " " + operacao + " " + num2 + " é: " + resultado);
}