export default function ClassNavigator({ classes, selected, onSelect }) {
  return (
    <div className="sticky top-16 z-40 bg-paper-white border-b border-metric-grey">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="flex items-center gap-0 overflow-x-auto no-scrollbar" style={{ scrollbarWidth: 'none' }}>
          <button
            onClick={() => onSelect(null)}
            className={`flex-shrink-0 px-6 py-4 text-sm font-bold uppercase tracking-widest border-b-2 transition-colors whitespace-nowrap ${
              !selected
                ? 'border-senac-red text-senac-red'
                : 'border-transparent text-gray-400 hover:text-ink-black'
            }`}
          >
            Todas
          </button>
          {classes.map(cls => (
            <button
              key={cls}
              onClick={() => onSelect(cls)}
              className={`flex-shrink-0 px-6 py-4 text-sm font-black uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap ${
                selected === cls
                  ? 'border-senac-red text-senac-red'
                  : 'border-transparent text-gray-400 hover:text-ink-black'
              }`}
            >
              {cls}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}