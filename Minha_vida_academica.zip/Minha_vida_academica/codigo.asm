global main
extern MessageBoxA    ; Função do Windows para criar a janela pop-up
extern ExitProcess    ; Função do Windows para fechar o programa

section .data
    ; No Windows, textos geralmente terminam com o número 0 (null-terminated)
    titulo db 'Parabens!', 0
    mensagem db 'Hello, World! Direto do Assembly no Windows.', 0

section .text
main:
    ; REGRA DO WINDOWS x64: Alinhar a pilha e reservar 32 bytes 
    ; conhecidos como "Shadow Space" antes de chamar qualquer função.
    sub rsp, 40             ; 32 bytes (shadow space) + 8 bytes (alinhamento)

    ; Passo 1: Chamar MessageBoxA(JanelaPai, Texto, Titulo, TipoBotao)
    ; A regra do Windows x64 diz que os 4 primeiros parâmetros vão nos 
    ; registradores RCX, RDX, R8 e R9, nesta exata ordem.
    
    mov rcx, 0              ; 1º param (RCX): 0 significa que não há janela "pai"
    lea rdx, [rel mensagem] ; 2º param (RDX): Endereço do texto da mensagem
    lea r8, [rel titulo]    ; 3º param (R8): Endereço do texto do título
    mov r9, 0               ; 4º param (R9): 0 significa "Mostrar apenas botão OK"
    call MessageBoxA        ; Dispara a função do Windows!

    ; Passo 2: Chamar ExitProcess(CodigoDeSaida) para fechar o programa limpo
    mov rcx, 0              ; 1º param (RCX): 0 significa que terminou sem erros
    call ExitProcess        ; Encerra o programa