import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import PageLayout from '@/components/layout/PageLayout';

// Pages
import Home from '@/pages/Home';
import PostDetail from '@/pages/PostDetail';
import MeuEspaco from '@/pages/MeuEspaco';
import PainelProfessor from '@/pages/PainelProfessor';
import Turmas from '@/pages/Turmas';
import Categorias from '@/pages/Categorias';
import Sobre from '@/pages/Sobre';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-paper-white">
        <div className="flex flex-col items-center gap-4">
          <div className="w-1 h-12 bg-senac-red animate-pulse" />
          <div className="text-xs text-gray-400 uppercase tracking-widest">EMED SENAC</div>
        </div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route element={<PageLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/post/:id" element={<PostDetail />} />
        <Route path="/meu-espaco" element={<MeuEspaco />} />
        <Route path="/painel-professor" element={<PainelProfessor />} />
        <Route path="/turmas" element={<Turmas />} />
        <Route path="/categorias" element={<Categorias />} />
        <Route path="/sobre" element={<Sobre />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App