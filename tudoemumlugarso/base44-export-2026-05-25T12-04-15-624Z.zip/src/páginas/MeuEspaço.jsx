const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from 'react';

import { Link } from 'react-router-dom';
import { PenSquare, Eye, Clock, CheckCircle2, XCircle, Plus, Trash2 } from 'lucide-react';
import PostForm from '@/components/studio/PostForm';

const STATUS_CONFIG = {
  rascunho: { label: 'Rascunho', color: 'bg-gray-100 text-gray-600', icon: Clock },
  pendente: { label: 'Aguardando Revisão', color: 'bg-amber-100 text-amber-700', icon: Clock },
  publicado: { label: 'Publicado', color: 'bg-green-100 text-green-700', icon: CheckCircle2 },
  rejeitado: { label: 'Rejeitado', color: 'bg-red-100 text-red-700', icon: XCircle },
};

export default function MeuEspaco() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingPost, setEditingPost] = useState(null);

  useEffect(() => {
    db.auth.me().then(u => {
      setUser(u);
      return db.entities.Post.filter({ created_by: u.email }, '-created_date');
    }).then(data => {
      setPosts(data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const handleDelete = async (postId) => {
    if (!window.confirm('Tem certeza que quer apagar esta publicação?')) return;
    await db.entities.Post.delete(postId);
    setPosts(prev => prev.filter(p => p.id !== postId));
  };

  const handleSave = (saved) => {
    setPosts(prev => {
      const exists = prev.find(p => p.id === saved.id);
      if (exists) return prev.map(p => p.id === saved.id ? saved : p);
      return [saved, ...prev];
    });
    setShowForm(false);
    setEditingPost(null);
  };

  if (showForm || editingPost) {
    return (
      <PostForm
        post={editingPost}
        onSave={handleSave}
        onCancel={() => { setShowForm(false); setEditingPost(null); }}
        user={user}
      />
    );
  }

  return (
    <div className="min-h-screen bg-paper-white">
      <div className="max-w-5xl mx-auto px-6 lg:px-12 py-12">
        {/* Header */}
        <div className="flex items-center justify-between mb-12">
          <div className="red-thread">
            <div className="text-xs text-gray-400 uppercase tracking-widest mb-1">Área do Aluno / Professor</div>
            <h1 className="text-3xl font-black text-ink-black uppercase tracking-tight">Meu Espaço</h1>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center gap-2 bg-senac-red text-white px-6 py-3 font-bold uppercase tracking-wide text-sm hover:bg-red-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Nova Publicação
          </button>
        </div>

        {/* Status ribbon */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {Object.entries(STATUS_CONFIG).map(([key, cfg]) => {
            const count = posts.filter(p => p.status === key).length;
            const Icon = cfg.icon;
            return (
              <div key={key} className={`p-4 border border-metric-grey ${count > 0 ? 'border-l-4 border-l-senac-red' : ''}`}>
                <div className="flex items-center gap-2 mb-1">
                  <Icon className="w-3 h-3 text-gray-400" />
                  <span className="text-xs text-gray-400 uppercase tracking-widest">{cfg.label}</span>
                </div>
                <div className="text-2xl font-black text-ink-black">{count}</div>
              </div>
            );
          })}
        </div>

        {/* Posts list */}
        {loading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-100 animate-pulse" />
            ))}
          </div>
        ) : posts.length === 0 ? (
          <div className="text-center py-24 border border-dashed border-metric-grey">
            <PenSquare className="w-12 h-12 text-metric-grey mx-auto mb-4" />
            <p className="text-gray-400 mb-6">Você ainda não publicou nada. Que tal começar agora?</p>
            <button
              onClick={() => setShowForm(true)}
              className="bg-senac-red text-white px-6 py-3 font-bold uppercase tracking-wide text-sm hover:bg-red-700"
            >
              Criar Primeira Publicação
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {posts.map(post => {
              const cfg = STATUS_CONFIG[post.status] || STATUS_CONFIG.rascunho;
              const Icon = cfg.icon;
              return (
                <div key={post.id} className="bg-white border border-metric-grey p-5 flex items-center gap-5 group hover:border-senac-red transition-colors">
                  {/* Cover thumb */}
                  <div className="w-16 h-16 flex-shrink-0 overflow-hidden bg-gray-100">
                    {post.cover_image_url ? (
                      <img src={post.cover_image_url} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-gray-100 flex items-center justify-center text-xl font-black text-gray-300">
                        {post.class_name?.[0]}
                      </div>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-1">
                      <span className={`inline-flex items-center gap-1 text-xs font-bold uppercase px-2 py-0.5 ${cfg.color}`}>
                        <Icon className="w-3 h-3" />
                        {cfg.label}
                      </span>
                      <span className="text-xs text-senac-red font-bold uppercase">{post.class_name}</span>
                    </div>
                    <h3 className="font-black text-ink-black truncate">{post.title}</h3>
                    {post.reviewer_feedback && post.status === 'rejeitado' && (
                      <p className="text-xs text-red-600 mt-1 italic truncate">"{post.reviewer_feedback}"</p>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-3 flex-shrink-0">
                    <div className="flex items-center gap-1 text-xs text-gray-400">
                      <Eye className="w-3 h-3" />
                      {post.views || 0}
                    </div>
                    <button
                      onClick={() => setEditingPost(post)}
                      className="p-2 text-gray-400 hover:text-senac-red transition-colors"
                    >
                      <PenSquare className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(post.id)}
                      className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}