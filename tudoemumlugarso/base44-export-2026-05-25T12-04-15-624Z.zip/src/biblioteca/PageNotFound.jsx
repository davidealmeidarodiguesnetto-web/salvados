const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useLocation } from 'react-router-dom';

import { useQuery } from '@tanstack/react-query';

export default function PageNotFound({}) {
    const location = useLocation();
    const pageName = location.pathname.substring(1);

    const { data: authData, isFetched } = useQuery({
        queryKey: ['user'],
        queryFn: async () => {
            try {
                const user = await db.auth.me();
                return { user, isAuthenticated: true };
            } catch (error) {
                return { user: null, isAuthenticated: false };
            }
        }
    });
    
    return (
        <div className="min-h-screen flex items-center justify-center p-6" style={{ backgroundColor: '#F8F8F8' }}>
            <div className="max-w-md w-full text-center">
                <div className="flex items-center justify-center gap-2 mb-8">
                    <div className="w-8 h-8 flex items-center justify-center" style={{ backgroundColor: '#E30613' }}>
                        <span className="text-white font-black text-sm">S</span>
                    </div>
                    <span className="font-black text-xs uppercase tracking-widest" style={{ color: '#1A1A1A' }}>EMED SENAC</span>
                </div>

                <div className="flex items-baseline justify-center gap-0 mb-4">
                    <span className="font-black leading-none" style={{ fontSize: '8rem', color: '#E30613' }}>4</span>
                    <span className="font-black leading-none" style={{ fontSize: '8rem', color: '#D1D1D1' }}>04</span>
                </div>
                
                <div className="w-12 h-1 mx-auto mb-6" style={{ backgroundColor: '#E30613' }} />

                <h2 className="text-2xl font-black uppercase tracking-tight mb-3" style={{ color: '#1A1A1A' }}>
                    Página não encontrada
                </h2>
                <p className="text-sm leading-relaxed mb-8" style={{ color: '#6b7280' }}>
                    A página <strong>"{pageName}"</strong> não existe neste jornal.
                </p>

                {isFetched && authData.isAuthenticated && authData.user?.role === 'admin' && (
                    <div className="mb-6 p-4 border border-amber-200 bg-amber-50 text-left">
                        <p className="text-xs font-bold text-amber-700 uppercase tracking-widest mb-1">Nota Admin</p>
                        <p className="text-xs text-amber-600">Esta página ainda não foi implementada. Peça ao assistente para criá-la.</p>
                    </div>
                )}
                
                <button 
                    onClick={() => window.location.href = '/'} 
                    className="inline-flex items-center gap-2 px-8 py-3 text-sm font-bold uppercase tracking-wide text-white transition-colors"
                    style={{ backgroundColor: '#E30613' }}
                    onMouseEnter={e => e.currentTarget.style.backgroundColor = '#b91c1c'}
                    onMouseLeave={e => e.currentTarget.style.backgroundColor = '#E30613'}
                >
                    Voltar ao Início
                </button>
            </div>
        </div>
    )
}