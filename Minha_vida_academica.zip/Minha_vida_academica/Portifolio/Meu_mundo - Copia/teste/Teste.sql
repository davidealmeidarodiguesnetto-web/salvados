CREATE TABLE FORNECEDOR (
    ID_FORNECEDOR INT PRIMARY KEY,
    NOME_FORNECEDOR VARCHAR(100) NOT NULL,
    CNPJ_FORNECEDOR VARCHAR(20) NOT NULL,
    TELEFONE_FORNECEDOR VARCHAR(15),
    EMAIL_FORNECEDOR VARCHAR(100)
);

INSERT INTO FORNECEDOR (ID_FORNECEDOR, NOME_FORNECEDOR, CNPJ_FORNECEDOR, TELEFONE_FORNECEDOR, EMAIL_FORNECEDOR) VALUES

(1, 'Ambev', '00.000.001/0001-01', '(11) 90000-0001', 'contato@ambev.com'),
(2, 'Nestlé Brasil', '00.000.002/0001-02', '(11) 90000-0002', 'contato@nestle.com'),
(3, 'Coca-Cola Brasil', '00.000.003/0001-03', '(11) 90000-0003', 'contato@coca-cola.com'),
(4, 'Unilever Brasil', '00.000.004/0001-04', '(11) 90000-0004', 'contato@unilever.com'),
(5, 'JBS', '00.000.005/0001-05', '(11) 90000-0005', 'contato@jbs.com'),

(6, 'BRF', '00.000.006/0001-06', '(11) 90000-0006', 'contato@brf.com'),
(7, 'Carrefour Brasil', '00.000.007/0001-07', '(11) 90000-0007', 'contato@carrefour.com'),
(8, 'Grupo Pão de Açúcar', '00.000.008/0001-08', '(11) 90000-0008', 'contato@gpabr.com'),
(9, 'Assaí Atacadista', '00.000.009/0001-09', '(11) 90000-0009', 'contato@assai.com.br'),
(10, 'Atacadão', '00.000.010/0001-10', '(11) 90000-0010', 'contato@atacadao.com.br'),

(11, 'Natura', '00.000.011/0001-11', '(11) 90000-0011', 'contato@natura.com'),
(12, 'Boticário', '00.000.012/0001-12', '(11) 90000-0012', 'contato@boticario.com'),
(13, 'Lojas Americanas', '00.000.013/0001-13', '(11) 90000-0013', 'contato@americanas.com'),
(14, 'Magazine Luiza', '00.000.014/0001-14', '(11) 90000-0014', 'contato@magazineluiza.com'),
(15, 'Mercado Livre', '00.000.015/0001-15', '(11) 90000-0015', 'contato@mercadolivre.com'),

(16, 'Amazon Brasil', '00.000.016/0001-16', '(11) 90000-0016', 'contato@amazon.com'),
(17, 'Samsung Brasil', '00.000.017/0001-17', '(11) 90000-0017', 'contato@samsung.com'),
(18, 'LG Electronics', '00.000.018/0001-18', '(11) 90000-0018', 'contato@lg.com'),
(19, 'Dell Brasil', '00.000.019/0001-19', '(11) 90000-0019', 'contato@dell.com'),
(20, 'HP Brasil', '00.000.020/0001-20', '(11) 90000-0020', 'contato@hp.com'),

(21, 'Microsoft Brasil', '00.000.021/0001-21', '(11) 90000-0021', 'contato@microsoft.com'),
(22, 'IBM Brasil', '00.000.022/0001-22', '(11) 90000-0022', 'contato@ibm.com'),
(23, 'Oracle Brasil', '00.000.023/0001-23', '(11) 90000-0023', 'contato@oracle.com'),
(24, 'TOTVS', '00.000.024/0001-24', '(11) 90000-0024', 'contato@totvs.com'),
(25, 'Stefanini', '00.000.025/0001-25', '(11) 90000-0025', 'contato@stefanini.com'),

(26, 'Petrobras', '00.000.026/0001-26', '(21) 90000-0026', 'contato@petrobras.com'),
(27, 'Shell Brasil', '00.000.027/0001-27', '(21) 90000-0027', 'contato@shell.com'),
(28, 'Ipiranga', '00.000.028/0001-28', '(21) 90000-0028', 'contato@ipiranga.com'),
(29, 'Raízen', '00.000.029/0001-29', '(11) 90000-0029', 'contato@raizen.com'),
(30, 'Votorantim', '00.000.030/0001-30', '(11) 90000-0030', 'contato@votorantim.com'),

(31, 'Gerdau', '00.000.031/0001-31', '(11) 90000-0031', 'contato@gerdau.com'),
(32, 'Vale', '00.000.032/0001-32', '(21) 90000-0032', 'contato@vale.com'),
(33, 'Suzano', '00.000.033/0001-33', '(11) 90000-0033', 'contato@suzano.com'),
(34, 'Klabin', '00.000.034/0001-34', '(11) 90000-0034', 'contato@klabin.com'),
(35, 'Riachuelo', '00.000.035/0001-35', '(11) 90000-0035', 'contato@riachuelo.com'),

(36, 'Renner', '00.000.036/0001-36', '(11) 90000-0036', 'contato@renner.com'),
(37, 'Havan', '00.000.037/0001-37', '(47) 90000-0037', 'contato@havan.com'),
(38, 'Koch', '00.000.038/0001-38', '(11) 90000-0038', 'contato@koch.com'),
(39, 'Grupo Bimbo', '00.000.039/0001-39', '(11) 90000-0039', 'contato@bimbo.com'),
(40, 'Danone Brasil', '00.000.040/0001-40', '(11) 90000-0040', 'contato@danone.com'),

(41, 'Heineken Brasil', '00.000.041/0001-41', '(11) 90000-0041', 'contato@heineken.com'),
(42, 'PepsiCo Brasil', '00.000.042/0001-42', '(11) 90000-0042', 'contato@pepsico.com'),
(43, 'P&G Brasil', '00.000.043/0001-43', '(11) 90000-0043', 'contato@pg.com'),
(44, 'Colgate-Palmolive', '00.000.044/0001-44', '(11) 90000-0044', 'contato@colgate.com'),
(45, 'Johnson & Johnson', '00.000.045/0001-45', '(11) 90000-0045', 'contato@jnj.com'),

(46, '3M Brasil', '00.000.046/0001-46', '(11) 90000-0046', 'contato@3m.com'),
(47, 'Bosch Brasil', '00.000.047/0001-47', '(11) 90000-0047', 'contato@bosch.com'),
(48, 'Siemens Brasil', '00.000.048/0001-48', '(11) 90000-0048', 'contato@siemens.com'),
(49, 'Electrolux Brasil', '00.000.049/0001-49', '(11) 90000-0049', 'contato@electrolux.com'),
(50, 'Panasonic Brasil', '00.000.050/0001-50', '(11) 90000-0050', 'contato@panasonic.com');

SELECT * FROM FORNECEDOR;

