import { Link, useLocation } from 'react-router-dom';
import { useState } from 'react';
import { Menu, X, PenSquare } from 'lucide-react';

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const location = useLocation();

  const links = [
    { label: 'Início', path: '/' },
    { label: 'Turmas', path: '/turmas' },
    { label: 'Categorias', path: '/categorias' },
    { label: 'Professores', path: '/painel-professor' },
    { label: 'Sobre', path: '/sobre' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-paper-white border-b border-metric-grey" style={{ borderBottomColor: '#D1D1D1' }}>
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-8 h-8 bg-senac-red flex items-center justify-center flex-shrink-0">
              <span className="text-white font-black text-xs leading-none">S</span>
            </div>
            <div className="leading-none">
              <div className="font-black text-ink-black text-sm tracking-tight uppercase">EMED SENAC</div>
              <div className="font-light text-senac-red text-xs tracking-widest uppercase">Jornal</div>
            </div>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-8">
            {links.map(l => (
              <Link
                key={l.path}
                to={l.path}
                className={`text-sm font-medium tracking-wide uppercase transition-colors hover:text-senac-red ${
                  location.pathname === l.path ? 'text-senac-red border-b-2 border-senac-red pb-0.5' : 'text-ink-black'
                }`}
              >
                {l.label}
              </Link>
            ))}
          </div>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-3">
            <Link
              to="/meu-espaco"
              className="flex items-center gap-2 bg-senac-red text-white px-5 py-2 text-sm font-bold uppercase tracking-wide hover:bg-red-700 transition-colors"
            >
              <PenSquare className="w-4 h-4" />
              Publicar
            </Link>
          </div>

          {/* Mobile toggle */}
          <button className="md:hidden p-2" onClick={() => setOpen(!open)}>
            {open ? <X className="w-5 h-5 text-ink-black" /> : <Menu className="w-5 h-5 text-ink-black" />}
          </button>
        </div>

        {/* Mobile menu */}
        {open && (
          <div className="md:hidden border-t border-metric-grey py-4 space-y-3">
            {links.map(l => (
              <Link
                key={l.path}
                to={l.path}
                className="block text-sm font-medium text-ink-black hover:text-senac-red uppercase tracking-wide py-2"
                onClick={() => setOpen(false)}
              >
                {l.label}
              </Link>
            ))}
            <Link
              to="/meu-espaco"
              className="block bg-senac-red text-white text-center py-3 text-sm font-bold uppercase tracking-wide"
              onClick={() => setOpen(false)}
            >
              Publicar
            </Link>
          </div>
        )}
      </div>
    </nav>
  );
}