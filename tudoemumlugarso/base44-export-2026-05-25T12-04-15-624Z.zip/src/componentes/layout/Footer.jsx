import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-ink-black text-white mt-24">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-senac-red flex items-center justify-center">
                <span className="text-white font-black text-sm">S</span>
              </div>
              <div>
                <div className="font-black text-white text-base uppercase tracking-tight">EMED SENAC</div>
                <div className="font-light text-senac-red text-xs tracking-widest uppercase">Jornal Escolar</div>
              </div>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed max-w-xs">
              O arquivo vivo das conquistas, projetos e histórias das turmas do EMED SENAC.
            </p>
          </div>

          {/* Links */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-senac-red mb-4">Navegação</h3>
            <ul className="space-y-3">
              {[
                { label: 'Início', path: '/' },
                { label: 'Turmas', path: '/turmas' },
                { label: 'Categorias', path: '/categorias' },
                { label: 'Meu Espaço', path: '/meu-espaco' },
                { label: 'Sobre', path: '/sobre' },
              ].map(l => (
                <li key={l.path}>
                  <Link to={l.path} className="text-sm text-gray-400 hover:text-white transition-colors">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Info */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-senac-red mb-4">SENAC</h3>
            <p className="text-sm text-gray-400 leading-relaxed">
              Escola de Educação Profissional<br />
              EMED — Educação de Jovens e Adultos<br />
              SENAC Brasil
            </p>
            <div className="mt-6 h-px bg-senac-red w-12"></div>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-gray-500 uppercase tracking-widest">
            © 2026 EMED SENAC — Jornal Escolar
          </p>
          <p className="text-xs text-gray-600">
            Feito com orgulho pelos alunos e professores
          </p>
        </div>
      </div>
    </footer>
  );
}