import { Link } from 'react-router-dom';
import { PenSquare, Users, BookOpen, Star } from 'lucide-react';

export default function Sobre() {
  return (
    <div className="min-h-screen bg-paper-white">
      {/* Hero band */}
      <div className="bg-ink-black py-24 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-1 h-12 bg-senac-red" />
            <span className="text-xs text-gray-400 uppercase tracking-widest">EMED SENAC</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-black text-white leading-none tracking-tight mb-6">
            O JORNAL<br /><span className="text-senac-red">ESCOLAR</span>
          </h1>
          <p className="text-lg text-gray-300 max-w-2xl leading-relaxed">
            Um espaço criado para que as turmas do EMED SENAC possam compartilhar seus projetos, eventos, trabalhos e conquistas com toda a comunidade escolar.
          </p>
        </div>
      </div>

      {/* How it works */}
      <div className="max-w-4xl mx-auto px-6 lg:px-12 py-24">
        <div className="flex items-center gap-4 mb-12">
          <div className="w-1 h-8 bg-senac-red" />
          <h2 className="text-2xl font-black text-ink-black uppercase tracking-tight">Como Funciona</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {[
            {
              step: '01',
              icon: PenSquare,
              title: 'Crie e Envie',
              desc: 'Alunos e professores criam publicações com texto, fotos e detalhes do projeto. Depois enviam para revisão.',
            },
            {
              step: '02',
              icon: Users,
              title: 'Revisão do Professor',
              desc: 'O professor revisa a publicação, pode deixar um feedback construtivo e aprova ou solicita ajustes.',
            },
            {
              step: '03',
              icon: Star,
              title: 'Publicado para Todos',
              desc: 'Uma vez aprovado, o trabalho é visto por todos do EMED SENAC. Os melhores viram destaque na capa!',
            },
          ].map(item => {
            const Icon = item.icon;
            return (
              <div key={item.step} className="border border-metric-grey p-8 bg-white">
                <div className="text-5xl font-black text-metric-grey mb-4">{item.step}</div>
                <div className="w-8 h-8 bg-senac-red flex items-center justify-center mb-4">
                  <Icon className="w-4 h-4 text-white" />
                </div>
                <h3 className="font-black text-ink-black text-lg mb-2 uppercase">{item.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{item.desc}</p>
              </div>
            );
          })}
        </div>

        {/* What can be published */}
        <div className="bg-ink-black p-8 md:p-12 mb-16">
          <h2 className="text-2xl font-black text-white uppercase tracking-tight mb-8">O Que Publicar</h2>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {[
              { emoji: '📐', label: 'Projetos' },
              { emoji: '📅', label: 'Eventos' },
              { emoji: '📋', label: 'Trabalhos' },
              { emoji: '🏆', label: 'Conquistas' },
              { emoji: '📰', label: 'Notícias' },
            ].map(item => (
              <div key={item.label} className="text-center py-6 border border-gray-700 hover:border-senac-red transition-colors">
                <div className="text-3xl mb-2">{item.emoji}</div>
                <div className="text-xs font-black text-white uppercase tracking-widest">{item.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="flex flex-col sm:flex-row gap-4">
          <Link
            to="/meu-espaco"
            className="flex items-center justify-center gap-2 bg-senac-red text-white px-8 py-4 font-black uppercase tracking-wide hover:bg-red-700 transition-colors"
          >
            <PenSquare className="w-5 h-5" />
            Começar a Publicar
          </Link>
          <Link
            to="/"
            className="flex items-center justify-center gap-2 border-2 border-ink-black text-ink-black px-8 py-4 font-black uppercase tracking-wide hover:bg-ink-black hover:text-white transition-colors"
          >
            Ver Publicações
          </Link>
        </div>
      </div>
    </div>
  );
}