const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from 'react';

import { ArrowLeft, Upload, X, Send } from 'lucide-react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

const CATEGORIES = [
  { value: 'projeto', label: 'Projeto' },
  { value: 'evento', label: 'Evento' },
  { value: 'trabalho', label: 'Trabalho' },
  { value: 'conquista', label: 'Conquista' },
  { value: 'noticia', label: 'Notícia' },
];

export default function PostForm({ post, onSave, onCancel, user }) {
  const [form, setForm] = useState({
    title: post?.title || '',
    summary: post?.summary || '',
    content: post?.content || '',
    category: post?.category || 'projeto',
    class_name: post?.class_name || '',
    author_name: post?.author_name || user?.full_name || '',
    cover_image_url: post?.cover_image_url || '',
    extra_images: post?.extra_images || [],
    status: post?.status || 'rascunho',
  });
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);

  const set = (key, val) => setForm(prev => ({ ...prev, [key]: val }));

  const handleCoverUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await db.integrations.Core.UploadFile({ file });
    set('cover_image_url', file_url);
    setUploading(false);
  };

  const handleExtraUpload = async (e) => {
    const files = Array.from(e.target.files);
    setUploading(true);
    const urls = await Promise.all(files.map(f => db.integrations.Core.UploadFile({ file: f }).then(r => r.file_url)));
    set('extra_images', [...form.extra_images, ...urls]);
    setUploading(false);
  };

  const removeExtra = (i) => {
    set('extra_images', form.extra_images.filter((_, idx) => idx !== i));
  };

  const handleSubmit = async (submitStatus) => {
    setSaving(true);
    const data = { ...form, status: submitStatus };
    let saved;
    if (post?.id) {
      saved = await db.entities.Post.update(post.id, data);
    } else {
      saved = await db.entities.Post.create(data);
    }
    setSaving(false);
    onSave(saved);
  };

  return (
    <div className="min-h-screen bg-paper-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12 py-12">
        {/* Header */}
        <div className="flex items-center gap-4 mb-10">
          <button onClick={onCancel} className="p-2 hover:text-senac-red transition-colors text-gray-400">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="red-thread">
            <div className="text-xs text-gray-400 uppercase tracking-widest mb-0.5">Estúdio Editorial</div>
            <h1 className="text-2xl font-black text-ink-black uppercase tracking-tight">
              {post ? 'Editar Publicação' : 'Nova Publicação'}
            </h1>
          </div>
        </div>

        <div className="space-y-8">
          {/* Cover image */}
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">
              Imagem de Capa
            </label>
            {form.cover_image_url ? (
              <div className="relative group">
                <img src={form.cover_image_url} alt="Capa" className="w-full h-64 object-cover" />
                <button
                  onClick={() => set('cover_image_url', '')}
                  className="absolute top-3 right-3 bg-white p-1 hover:bg-senac-red hover:text-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center h-48 border-2 border-dashed border-metric-grey cursor-pointer hover:border-senac-red transition-colors bg-white">
                <Upload className="w-8 h-8 text-metric-grey mb-2" />
                <span className="text-sm text-gray-400">Clique para fazer upload</span>
                <input type="file" accept="image/*" onChange={handleCoverUpload} className="hidden" />
              </label>
            )}
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">Título *</label>
            <input
              type="text"
              value={form.title}
              onChange={e => set('title', e.target.value)}
              placeholder="Título impactante da publicação..."
              className="w-full text-2xl font-black text-ink-black border-b-2 border-metric-grey focus:border-senac-red outline-none bg-transparent pb-2 placeholder:text-metric-grey placeholder:font-normal placeholder:text-lg"
            />
          </div>

          {/* Summary */}
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">Resumo</label>
            <textarea
              value={form.summary}
              onChange={e => set('summary', e.target.value)}
              placeholder="Um resumo curto que aparece nos cards e no destaque..."
              rows={2}
              className="w-full text-base text-gray-600 border-b border-metric-grey focus:border-senac-red outline-none bg-transparent pb-2 resize-none placeholder:text-metric-grey"
            />
          </div>

          {/* Meta fields */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">Turma *</label>
              <input
                type="text"
                value={form.class_name}
                onChange={e => set('class_name', e.target.value)}
                placeholder="Ex: 1ºA, 2ºB"
                className="w-full border-b border-metric-grey focus:border-senac-red outline-none bg-transparent pb-2 text-sm font-bold text-ink-black uppercase"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">Seu Nome</label>
              <input
                type="text"
                value={form.author_name}
                onChange={e => set('author_name', e.target.value)}
                placeholder="Nome do autor"
                className="w-full border-b border-metric-grey focus:border-senac-red outline-none bg-transparent pb-2 text-sm text-ink-black"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">Categoria *</label>
              <select
                value={form.category}
                onChange={e => set('category', e.target.value)}
                className="w-full border-b border-metric-grey focus:border-senac-red outline-none bg-transparent pb-2 text-sm font-bold text-ink-black uppercase"
              >
                {CATEGORIES.map(c => (
                  <option key={c.value} value={c.value}>{c.label}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Content editor */}
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">
              Conteúdo Completo
            </label>
            <div className="border border-metric-grey bg-white">
              <ReactQuill
                value={form.content}
                onChange={val => set('content', val)}
                placeholder="Descreva o projeto, evento ou trabalho em detalhes..."
                style={{ minHeight: 300 }}
              />
            </div>
          </div>

          {/* Extra images */}
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">
              Galeria de Imagens
            </label>
            <div className="flex gap-3 flex-wrap">
              {form.extra_images.map((url, i) => (
                <div key={i} className="relative w-24 h-24">
                  <img src={url} alt="" className="w-full h-full object-cover" />
                  <button
                    onClick={() => removeExtra(i)}
                    className="absolute -top-1 -right-1 bg-senac-red text-white w-5 h-5 flex items-center justify-center text-xs hover:bg-red-700"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
              <label className="w-24 h-24 flex items-center justify-center border-2 border-dashed border-metric-grey cursor-pointer hover:border-senac-red transition-colors bg-white">
                <Upload className="w-5 h-5 text-metric-grey" />
                <input type="file" accept="image/*" multiple onChange={handleExtraUpload} className="hidden" />
              </label>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-col sm:flex-row gap-4 pt-6 border-t border-metric-grey">
            <button
              onClick={() => handleSubmit('rascunho')}
              disabled={saving || uploading || !form.title || !form.class_name}
              className="flex-1 py-3 text-sm font-bold uppercase tracking-wide border-2 border-ink-black text-ink-black hover:bg-ink-black hover:text-white transition-colors disabled:opacity-40"
            >
              Salvar Rascunho
            </button>
            <button
              onClick={() => handleSubmit('pendente')}
              disabled={saving || uploading || !form.title || !form.class_name}
              className="flex-1 flex items-center justify-center gap-2 py-3 text-sm font-bold uppercase tracking-wide bg-senac-red text-white hover:bg-red-700 transition-colors disabled:opacity-40"
            >
              <Send className="w-4 h-4" />
              {saving ? 'Enviando...' : 'Enviar para Revisão'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}