import { Link } from 'react-router-dom';
import { ArrowRight, Star } from 'lucide-react';

const CATEGORY_LABELS = {
  projeto: 'Projeto',
  evento: 'Evento',
  trabalho: 'Trabalho',
  conquista: 'Conquista',
  noticia: 'Notícia',
};

export default function HeroSection({ post }) {
  if (!post) {
    return (
      <div className="relative w-full bg-ink-black" style={{ height: '70vh', minHeight: 480 }}>
        <div className="absolute inset-0 flex items-end">
          <div className="max-w-7xl mx-auto px-6 lg:px-12 pb-16 w-full">
            <div className="max-w-2xl">
              <span className="inline-block bg-senac-red text-white text-xs font-bold uppercase tracking-widest px-3 py-1 mb-6">
                Seja bem-vindo
              </span>
              <h1 className="text-5xl md:text-7xl font-black text-white leading-none tracking-tight mb-6">
                EMED SENAC<br />
                <span className="text-senac-red">Jornal</span>
              </h1>
              <p className="text-lg text-gray-300 max-w-lg leading-relaxed">
                O espaço das turmas para compartilhar projetos, eventos e conquistas com toda a comunidade SENAC.
              </p>
            </div>
          </div>
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-ink-black via-ink-black/60 to-transparent"></div>
        <div
          className="absolute inset-0 brutalist-img"
          style={{
            backgroundImage: `url(https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=1400&q=80)`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            mixBlendMode: 'overlay',
            opacity: 0.3
          }}
        />
      </div>
    );
  }

  return (
    <Link to={`/post/${post.id}`} className="block">
      <div className="relative w-full bg-ink-black group" style={{ height: '70vh', minHeight: 480 }}>
        {/* Background image */}
        {post.cover_image_url && (
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `url(${post.cover_image_url})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              transition: 'transform 0.6s ease',
            }}
          />
        )}
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-ink-black via-ink-black/50 to-transparent" />

        {/* Red thread left accent */}
        <div className="absolute left-0 top-0 bottom-0 w-1 bg-senac-red" />

        {/* Content */}
        <div className="absolute inset-0 flex items-end">
          <div className="max-w-7xl mx-auto px-6 lg:px-12 pb-16 w-full">
            <div className="max-w-3xl">
              <div className="flex items-center gap-3 mb-4">
                <div className="flex items-center gap-1 bg-senac-red text-white text-xs font-bold uppercase tracking-widest px-3 py-1">
                  <Star className="w-3 h-3" />
                  Destaque da Semana
                </div>
                {post.category && (
                  <span className="text-white text-xs font-medium uppercase tracking-widest opacity-70">
                    {CATEGORY_LABELS[post.category] || post.category}
                  </span>
                )}
              </div>

              <h1 className="text-4xl md:text-6xl font-black text-white leading-none tracking-tight mb-4 group-hover:text-senac-red transition-colors duration-300">
                {post.title}
              </h1>

              {post.summary && (
                <p className="text-lg text-gray-300 max-w-xl leading-relaxed mb-6">
                  {post.summary}
                </p>
              )}

              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <div className="w-px h-8 bg-senac-red" />
                  <div>
                    <div className="text-xs text-gray-400 uppercase tracking-widest">Turma</div>
                    <div className="text-sm font-bold text-white">{post.class_name}</div>
                  </div>
                </div>
                {post.author_name && (
                  <div className="flex items-center gap-2">
                    <div className="w-px h-8 bg-metric-grey opacity-40" />
                    <div>
                      <div className="text-xs text-gray-400 uppercase tracking-widest">Por</div>
                      <div className="text-sm font-bold text-white">{post.author_name}</div>
                    </div>
                  </div>
                )}
                <div className="ml-auto flex items-center gap-2 text-white font-bold text-sm uppercase tracking-wide group-hover:text-senac-red transition-colors">
                  Ler mais <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}