const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect, useMemo } from 'react';

import PostCard from '@/components/home/PostCard';
import { Users } from 'lucide-react';

export default function Turmas() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedClass, setSelectedClass] = useState(null);

  useEffect(() => {
    db.entities.Post.filter({ status: 'publicado' }, '-created_date', 100)
      .then(data => { setPosts(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const classGroups = useMemo(() => {
    const map = {};
    posts.forEach(p => {
      if (!p.class_name) return;
      if (!map[p.class_name]) map[p.class_name] = [];
      map[p.class_name].push(p);
    });
    return Object.entries(map).sort(([a], [b]) => a.localeCompare(b));
  }, [posts]);

  const classes = classGroups.map(([cls]) => cls);

  return (
    <div className="min-h-screen bg-paper-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-16">
        {/* Header */}
        <div className="flex items-center gap-4 mb-12">
          <div className="w-1 h-12 bg-senac-red" />
          <div>
            <div className="text-xs text-gray-400 uppercase tracking-widest mb-1">EMED SENAC</div>
            <h1 className="text-3xl font-black text-ink-black uppercase tracking-tight">Turmas</h1>
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-12">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="h-20 bg-gray-100 animate-pulse" />
            ))}
          </div>
        ) : (
          <>
            {/* Class grid selector */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-12">
              <button
                onClick={() => setSelectedClass(null)}
                className={`py-6 text-center border-2 transition-all font-black text-sm uppercase tracking-widest ${
                  !selectedClass
                    ? 'bg-senac-red border-senac-red text-white'
                    : 'bg-white border-metric-grey text-gray-400 hover:border-ink-black hover:text-ink-black'
                }`}
              >
                <Users className="w-5 h-5 mx-auto mb-1" />
                Todas
              </button>
              {classes.map(cls => {
                const count = classGroups.find(([c]) => c === cls)?.[1]?.length || 0;
                return (
                  <button
                    key={cls}
                    onClick={() => setSelectedClass(cls)}
                    className={`py-6 text-center border-2 transition-all ${
                      selectedClass === cls
                        ? 'bg-senac-red border-senac-red text-white'
                        : 'bg-white border-metric-grey text-gray-400 hover:border-ink-black hover:text-ink-black'
                    }`}
                  >
                    <div className={`text-2xl font-black ${selectedClass === cls ? 'text-white' : 'text-ink-black'}`}>{cls}</div>
                    <div className={`text-xs mt-1 ${selectedClass === cls ? 'text-red-200' : 'text-gray-400'}`}>{count} posts</div>
                  </button>
                );
              })}
            </div>

            {/* Posts for selected class or all */}
            {!selectedClass ? (
              classGroups.map(([cls, clsPosts]) => (
                <div key={cls} className="mb-16">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-1 h-6 bg-senac-red" />
                    <h2 className="text-xl font-black text-ink-black uppercase tracking-tight">Turma {cls}</h2>
                    <div className="flex-1 h-px bg-metric-grey" />
                    <span className="text-sm text-gray-400">{clsPosts.length} publicações</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {clsPosts.slice(0, 3).map(p => <PostCard key={p.id} post={p} />)}
                  </div>
                </div>
              ))
            ) : (
              <div>
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-1 h-8 bg-senac-red" />
                  <h2 className="text-2xl font-black text-ink-black uppercase">Turma {selectedClass}</h2>
                  <div className="flex-1 h-px bg-metric-grey" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {classGroups.find(([c]) => c === selectedClass)?.[1]?.map(p => (
                    <PostCard key={p.id} post={p} />
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}