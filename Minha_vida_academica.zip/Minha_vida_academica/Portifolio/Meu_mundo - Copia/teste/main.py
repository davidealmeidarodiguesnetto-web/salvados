from fastapi import FastAPI

app = FastAPI(title="Minha Primeira API com Grok")

@app.get("/")
async def root():
    return {"message": "Olá! Estou aprendendo FastAPI com o Grok 🚀"}

@app.get("/items/{item_id}")
async def read_item(item_id: int, q: str | None = None):
    return {"item_id": item_id, "q": q}

@app.post("/items/")

async def create_item(item: dict):
    return {"item": item}
