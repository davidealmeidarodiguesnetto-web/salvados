const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect, useMemo } from 'react';

import HeroSection from '@/components/home/HeroSection';
import ClassNavigator from '@/components/home/ClassNavigator';
import PostCard from '@/components/home/PostCard';

export default function Home() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedClass, setSelectedClass] = useState(null);

  useEffect(() => {
    db.entities.Post.filter({ status: 'publicado' }, '-created_date', 50)
      .then(data => {
        setPosts(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const featuredPost = useMemo(() => posts.find(p => p.is_featured) || posts[0], [posts]);

  const classes = useMemo(() => {
    const set = new Set(posts.map(p => p.class_name).filter(Boolean));
    return Array.from(set).sort();
  }, [posts]);

  const filtered = useMemo(() => {
    const feed = posts.filter(p => p.id !== featuredPost?.id);
    if (!selectedClass) return feed;
    return feed.filter(p => p.class_name === selectedClass);
  }, [posts, selectedClass, featuredPost]);

  return (
    <div className="min-h-screen bg-paper-white">
      {/* Hero */}
      <HeroSection post={featuredPost} />

      {/* Class Navigator */}
      {classes.length > 0 && (
        <ClassNavigator
          classes={classes}
          selected={selectedClass}
          onSelect={setSelectedClass}
        />
      )}

      {/* Feed */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-16">
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white border border-metric-grey animate-pulse">
                <div className="h-52 bg-gray-100" />
                <div className="p-5 space-y-3">
                  <div className="h-3 bg-gray-100 w-1/3" />
                  <div className="h-5 bg-gray-100 w-3/4" />
                  <div className="h-3 bg-gray-100 w-full" />
                </div>
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-24">
            <div className="text-7xl font-black text-metric-grey mb-4">—</div>
            <p className="text-gray-400 text-lg">
              {selectedClass
                ? `Nenhuma publicação de ${selectedClass} ainda.`
                : 'Nenhuma publicação ainda. Seja o primeiro a publicar!'}
            </p>
          </div>
        ) : (
          <>
            {/* Section header */}
            <div className="flex items-center gap-4 mb-10">
              <div className="w-1 h-8 bg-senac-red flex-shrink-0" />
              <h2 className="text-2xl font-black text-ink-black uppercase tracking-tight">
                {selectedClass ? `Turma ${selectedClass}` : 'Publicações Recentes'}
              </h2>
              <div className="flex-1 h-px bg-metric-grey" />
              <span className="text-sm text-gray-400 font-medium">{filtered.length} publicações</span>
            </div>

            {/* Mosaic grid: first two large, rest normal */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              {filtered.slice(0, 2).map(post => (
                <PostCard key={post.id} post={post} large />
              ))}
            </div>
            {filtered.length > 2 && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filtered.slice(2).map(post => (
                  <PostCard key={post.id} post={post} />
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}