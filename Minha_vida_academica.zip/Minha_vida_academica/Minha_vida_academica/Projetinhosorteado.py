import re

print("SISTEMA DE CADASTRO ")

nome = input("Digite seu nome completo: ").strip()
while not nome:
    print("O nome não pode ficar em branco.")
    nome = input("Digite seu nome completo: ").strip()

email = input("Digite seu e-mail: ").strip()
while not re.match(r"[^@]+@[^@]+\.[^@]+", email):
    print("E-mail inválido. Por favor, insira um e-mail válido.")
    email = input("Digite seu e-mail: ").strip()
while True:
    senha = input("Crie uma senha: ")
    
    if len(senha) < 6:
        print("Erro: A senha deve ter pelo menos 6 caracteres.")
        continue
    if not re.search(r"[A-Z]", senha):
        print("Erro: A senha deve conter pelo menos uma letra maiúscula.")
        continue
    break

print("\n--- CADASTRO REALIZADO COM SUCESSO! ---")
print(f"Nome: {nome}")
print(f"E-mail: {email}")
print("Senha: *******")