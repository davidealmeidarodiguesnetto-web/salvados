const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect, useMemo } from 'react';

import PostCard from '@/components/home/PostCard';

const CATEGORIES = [
  { value: 'projeto', label: 'Projetos', icon: '📐' },
  { value: 'evento', label: 'Eventos', icon: '📅' },
  { value: 'trabalho', label: 'Trabalhos', icon: '📋' },
  { value: 'conquista', label: 'Conquistas', icon: '🏆' },
  { value: 'noticia', label: 'Notícias', icon: '📰' },
];

export default function Categorias() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    db.entities.Post.filter({ status: 'publicado' }, '-created_date', 100)
      .then(data => { setPosts(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    if (!selected) return posts;
    return posts.filter(p => p.category === selected);
  }, [posts, selected]);

  return (
    <div className="min-h-screen bg-paper-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-16">
        <div className="flex items-center gap-4 mb-12">
          <div className="w-1 h-12 bg-senac-red" />
          <div>
            <div className="text-xs text-gray-400 uppercase tracking-widest mb-1">EMED SENAC</div>
            <h1 className="text-3xl font-black text-ink-black uppercase tracking-tight">Categorias</h1>
          </div>
        </div>

        {/* Category grid */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-12">
          <button
            onClick={() => setSelected(null)}
            className={`p-6 text-center border-2 transition-all ${
              !selected ? 'bg-senac-red border-senac-red text-white' : 'bg-white border-metric-grey hover:border-ink-black'
            }`}
          >
            <div className="text-2xl mb-2">📚</div>
            <div className={`text-xs font-black uppercase tracking-widest ${!selected ? 'text-white' : 'text-gray-500'}`}>Todas</div>
            <div className={`text-lg font-black mt-1 ${!selected ? 'text-white' : 'text-ink-black'}`}>{posts.length}</div>
          </button>
          {CATEGORIES.map(cat => {
            const count = posts.filter(p => p.category === cat.value).length;
            return (
              <button
                key={cat.value}
                onClick={() => setSelected(cat.value)}
                className={`p-6 text-center border-2 transition-all ${
                  selected === cat.value ? 'bg-senac-red border-senac-red text-white' : 'bg-white border-metric-grey hover:border-ink-black'
                }`}
              >
                <div className="text-2xl mb-2">{cat.icon}</div>
                <div className={`text-xs font-black uppercase tracking-widest ${selected === cat.value ? 'text-white' : 'text-gray-500'}`}>{cat.label}</div>
                <div className={`text-lg font-black mt-1 ${selected === cat.value ? 'text-white' : 'text-ink-black'}`}>{count}</div>
              </button>
            );
          })}
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => <div key={i} className="h-72 bg-gray-100 animate-pulse" />)}
          </div>
        ) : (
          <>
            <div className="flex items-center gap-4 mb-8">
              <div className="w-1 h-6 bg-senac-red" />
              <h2 className="text-xl font-black text-ink-black uppercase">
                {selected ? CATEGORIES.find(c => c.value === selected)?.label : 'Todas as Publicações'}
              </h2>
              <div className="flex-1 h-px bg-metric-grey" />
              <span className="text-sm text-gray-400">{filtered.length}</span>
            </div>
            {filtered.length === 0 ? (
              <div className="text-center py-16 text-gray-400">Nenhuma publicação nesta categoria.</div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filtered.map(p => <PostCard key={p.id} post={p} />)}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}