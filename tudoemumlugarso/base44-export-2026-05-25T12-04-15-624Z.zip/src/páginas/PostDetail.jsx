const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';

import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { ArrowLeft, Eye, Calendar, BookOpen, User } from 'lucide-react';

const CATEGORY_LABELS = {
  projeto: 'Projeto', evento: 'Evento', trabalho: 'Trabalho',
  conquista: 'Conquista', noticia: 'Notícia',
};

export default function PostDetail() {
  const { id } = useParams();
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    db.entities.Post.filter({ id })
      .then(data => {
        const p = Array.isArray(data) ? data[0] : data;
        setPost(p);
        // Increment views
        if (p) db.entities.Post.update(p.id, { views: (p.views || 0) + 1 });
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-paper-white flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-metric-grey border-t-senac-red rounded-full animate-spin" />
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-paper-white flex items-center justify-center">
        <div className="text-center">
          <div className="text-8xl font-black text-metric-grey mb-4">404</div>
          <p className="text-gray-400 mb-6">Publicação não encontrada.</p>
          <Link to="/" className="bg-senac-red text-white px-6 py-3 font-bold uppercase tracking-wide text-sm hover:bg-red-700">
            Voltar ao Início
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-paper-white">
      {/* Back nav */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 pt-8">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-gray-400 hover:text-senac-red transition-colors font-medium uppercase tracking-wide">
          <ArrowLeft className="w-4 h-4" />
          Voltar
        </Link>
      </div>

      {/* Cover image - full bleed */}
      {post.cover_image_url && (
        <div className="relative mt-8 w-full" style={{ height: '60vh', minHeight: 360 }}>
          <img src={post.cover_image_url} alt={post.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-paper-white via-transparent to-transparent" />
        </div>
      )}

      {/* Main layout: sidebar + content */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-12">
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Left metadata sidebar */}
          <aside className="lg:w-56 flex-shrink-0">
            <div className="lg:sticky lg:top-32 space-y-6">
              <div className="w-1 h-12 bg-senac-red" />

              <div>
                <p className="text-xs text-gray-400 uppercase tracking-widest mb-1">Categoria</p>
                <p className="text-sm font-black text-ink-black uppercase">
                  {CATEGORY_LABELS[post.category] || post.category}
                </p>
              </div>

              <div className="h-px bg-metric-grey" />

              <div>
                <p className="text-xs text-gray-400 uppercase tracking-widest mb-1">Turma</p>
                <p className="text-lg font-black text-senac-red">{post.class_name}</p>
              </div>

              {post.author_name && (
                <div>
                  <p className="text-xs text-gray-400 uppercase tracking-widest mb-1">Autor</p>
                  <div className="flex items-center gap-2">
                    <User className="w-3 h-3 text-gray-400" />
                    <p className="text-sm font-medium text-ink-black">{post.author_name}</p>
                  </div>
                </div>
              )}

              {post.reviewer_name && (
                <div>
                  <p className="text-xs text-gray-400 uppercase tracking-widest mb-1">Aprovado por</p>
                  <p className="text-sm font-medium text-ink-black">{post.reviewer_name}</p>
                </div>
              )}

              <div className="h-px bg-metric-grey" />

              {post.created_date && (
                <div>
                  <p className="text-xs text-gray-400 uppercase tracking-widest mb-1">Publicado em</p>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-3 h-3 text-gray-400" />
                    <p className="text-sm text-gray-500">
                      {format(new Date(post.created_date), "d 'de' MMMM 'de' yyyy", { locale: ptBR })}
                    </p>
                  </div>
                </div>
              )}

              <div>
                <div className="flex items-center gap-2 text-xs text-gray-400">
                  <Eye className="w-3 h-3" />
                  {post.views || 0} visualizações
                </div>
              </div>
            </div>
          </aside>

          {/* Content spine */}
          <article className="flex-1 max-w-3xl">
            <header className="mb-10">
              {post.category && (
                <span className="inline-block bg-senac-red text-white text-xs font-bold uppercase tracking-widest px-3 py-1 mb-4">
                  {CATEGORY_LABELS[post.category] || post.category}
                </span>
              )}
              <h1 className="text-4xl md:text-5xl font-black text-ink-black leading-tight tracking-tight mb-6">
                {post.title}
              </h1>
              {post.summary && (
                <p className="text-xl text-gray-500 leading-relaxed border-l-4 border-senac-red pl-5">
                  {post.summary}
                </p>
              )}
            </header>

            <div className="h-px bg-metric-grey mb-10" />

            {/* Content */}
            {post.content ? (
              <div
                className="prose prose-lg max-w-none text-ink-black leading-relaxed"
                style={{ fontFamily: 'Inter', fontSize: '1.125rem', lineHeight: '1.6' }}
                dangerouslySetInnerHTML={{ __html: post.content }}
              />
            ) : (
              <p className="text-gray-400 italic">Nenhum conteúdo adicional.</p>
            )}

            {/* Process gallery */}
            {post.extra_images && post.extra_images.length > 0 && (
              <div className="mt-16">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-1 h-6 bg-senac-red" />
                  <h3 className="text-sm font-black uppercase tracking-widest text-ink-black">Galeria de Imagens</h3>
                </div>
                <div className="flex gap-4 overflow-x-auto pb-4" style={{ scrollbarWidth: 'none' }}>
                  {post.extra_images.map((url, i) => (
                    <div key={i} className="flex-shrink-0 w-64 h-40 overflow-hidden">
                      <img src={url} alt={`Imagem ${i + 1}`} className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </article>
        </div>
      </div>
    </div>
  );
}