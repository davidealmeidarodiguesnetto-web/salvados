import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Eye } from 'lucide-react';

const CATEGORY_LABELS = {
  projeto: 'Projeto',
  evento: 'Evento',
  trabalho: 'Trabalho',
  conquista: 'Conquista',
  noticia: 'Notícia',
};

const CATEGORY_COLORS = {
  projeto: 'bg-blue-100 text-blue-800',
  evento: 'bg-purple-100 text-purple-800',
  trabalho: 'bg-amber-100 text-amber-800',
  conquista: 'bg-green-100 text-green-800',
  noticia: 'bg-red-100 text-red-800',
};

export default function PostCard({ post, large = false }) {
  const dateStr = post.created_date
    ? format(new Date(post.created_date), "d 'de' MMM", { locale: ptBR })
    : '';

  return (
    <Link to={`/post/${post.id}`} className="group block magazine-card bg-white border border-metric-grey overflow-hidden">
      {/* Image */}
      <div className={`relative overflow-hidden brutalist-img ${large ? 'h-72 md:h-96' : 'h-52'}`}>
        {post.cover_image_url ? (
          <img
            src={post.cover_image_url}
            alt={post.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
            <div className="text-5xl font-black text-gray-300">{post.class_name?.[0] || '?'}</div>
          </div>
        )}
        {/* Category badge */}
        <div className="absolute top-3 left-3">
          <span className={`text-xs font-bold uppercase tracking-widest px-2 py-1 ${CATEGORY_COLORS[post.category] || 'bg-gray-100 text-gray-700'}`}>
            {CATEGORY_LABELS[post.category] || post.category}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className={`p-5 ${large ? 'p-7' : ''}`}>
        {/* Meta top row */}
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-black text-senac-red uppercase tracking-widest">{post.class_name}</span>
          <span className="text-xs text-gray-400">{dateStr}</span>
        </div>

        {/* Title */}
        <h2 className={`font-black text-ink-black leading-tight tracking-tight group-hover:text-senac-red transition-colors ${large ? 'text-2xl mb-3' : 'text-lg mb-2'}`}>
          {post.title}
        </h2>

        {/* Summary */}
        {post.summary && (
          <p className="text-sm text-gray-500 leading-relaxed line-clamp-2 mb-4">
            {post.summary}
          </p>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-metric-grey">
          <div className="card-meta-reveal">
            {post.reviewer_name && (
              <span className="text-xs text-gray-400">
                Aprovado por <span className="text-ink-black font-medium">{post.reviewer_name}</span>
              </span>
            )}
          </div>
          <div className="flex items-center gap-4 w-full">
            {post.author_name && (
              <span className="text-xs text-gray-500 font-medium truncate">{post.author_name}</span>
            )}
            <div className="ml-auto flex items-center gap-1 text-xs text-gray-400">
              <Eye className="w-3 h-3" />
              {post.views || 0}
            </div>
            {/* Red thread arrow */}
            <div className="w-6 h-px bg-senac-red flex-shrink-0" />
          </div>
        </div>
      </div>
    </Link>
  );
}